#include <stdio.h> 
int main(void)
{ 
    printf("Welcome to CMPT 201\n");
    return 0;
}