#include <stdio.h> 
int main()
{ 
    printf("Welcome to CMPT 201\n");
}