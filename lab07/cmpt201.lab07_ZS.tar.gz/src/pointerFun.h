#ifndef POINTERFUN_H 
#define POINTERFUN_H 

void polynomial(double* coef, double* x, double* y, int* nc, int* na);
void str_reverso(char* str, int* n);
void str_center(char* str, int* n);

#endif

